import { motion, useScroll, useTransform } from "motion/react";
import { MilkyuLogo } from "./components/MilkyuLogo";
import { BobaCup } from "./components/BobaCup";

export default function App() {
  const { scrollYProgress } = useScroll();
  const heroOpacity = useTransform(scrollYProgress, [0, 0.2], [1, 0]);
  const heroScale = useTransform(scrollYProgress, [0, 0.2], [1, 0.95]);

  return (
    <div className="min-h-screen" style={{ background: "linear-gradient(180deg, #fff5f7 0%, #ffffff 50%, #f0f7f0 100%)" }}>
      <motion.header
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="fixed top-0 left-0 right-0 z-50 backdrop-blur-sm"
        style={{ background: "rgba(255, 255, 255, 0.8)" }}
      >
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <MilkyuLogo size={48} className="text-black" />
            <span style={{ fontSize: "1.5rem", fontWeight: 700, color: "#000", letterSpacing: "-0.02em" }}>
              Milkyu
            </span>
          </div>
          <nav className="hidden md:flex items-center gap-8" style={{ fontSize: "0.95rem", color: "#666" }}>
            <a href="#flavors" className="hover:opacity-70 transition-opacity">
              Rasa
            </a>
            <a href="#about" className="hover:opacity-70 transition-opacity">
              Tentang
            </a>
            <a href="#contact" className="hover:opacity-70 transition-opacity">
              Kontak
            </a>
          </nav>
        </div>
      </motion.header>

      <motion.section
        style={{ opacity: heroOpacity, scale: heroScale }}
        className="relative min-h-screen flex items-center justify-center px-6 pt-20"
      >
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="mb-8"
          >
            <MilkyuLogo size={120} className="mx-auto mb-6 text-black" animate={true} />
          </motion.div>

          <motion.h1
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            style={{
              fontSize: "4rem",
              fontWeight: 800,
              color: "#8b5a3c",
              lineHeight: 1.1,
              marginBottom: "1.5rem",
              letterSpacing: "-0.03em",
            }}
          >
            Boba Tea Premium
            <br />
            <span style={{ color: "#a8d5a8" }}>Dibuat dengan Cinta</span>
          </motion.h1>

          <motion.p
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            style={{ fontSize: "1.25rem", color: "#666", marginBottom: "2.5rem", maxWidth: "600px", margin: "0 auto" }}
          >
            Nikmati koleksi boba tea signature kami, dimana cita rasa autentik bertemu dengan keahlian modern
          </motion.p>

          <motion.button
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.7 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            style={{
              background: "linear-gradient(135deg, #ffb3c6 0%, #a8d5a8 100%)",
              color: "white",
              padding: "1rem 2.5rem",
              borderRadius: "9999px",
              fontSize: "1.1rem",
              fontWeight: 600,
              border: "none",
              cursor: "pointer",
              boxShadow: "0 10px 30px rgba(255, 179, 198, 0.3)",
            }}
          >
            Jelajahi Rasa
          </motion.button>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 1.2 }}
            className="absolute bottom-12 left-1/2 -translate-x-1/2"
          >
            <motion.div
              animate={{ y: [0, 10, 0] }}
              transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
              style={{ color: "#999", fontSize: "0.9rem" }}
            >
              ↓ Scroll untuk melihat
            </motion.div>
          </motion.div>
        </div>
      </motion.section>

      <section id="flavors" className="py-32 px-6" style={{ background: "rgba(255, 255, 255, 0.5)" }}>
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-20"
          >
            <h2
              style={{
                fontSize: "3rem",
                fontWeight: 700,
                color: "#8b5a3c",
                marginBottom: "1rem",
                letterSpacing: "-0.02em",
              }}
            >
              Rasa Signature Kami
            </h2>
            <p style={{ fontSize: "1.1rem", color: "#666", maxWidth: "600px", margin: "0 auto" }}>
              Tiga varian yang dibuat dengan tangan, masing-masing memiliki karakter uniknya. Tekan lama untuk merasakan dalam 3D.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-16">
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              viewport={{ once: true }}
            >
              <BobaCup
                flavor="matcha"
                title="Matcha Bliss"
                description="Bubuk matcha Jepang premium dengan susu creamy dan boba pearl segar"
              />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              viewport={{ once: true }}
            >
              <BobaCup
                flavor="strawberry"
                title="Strawberry Dream"
                description="Puree strawberry segar dicampur dengan susu dan topping potongan strawberry"
              />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
              viewport={{ once: true }}
            >
              <BobaCup
                flavor="chocolate"
                title="Chocolate Indulgence"
                description="Cokelat Belgia premium dicampur dengan susu creamy dan serutan cokelat"
              />
            </motion.div>
          </div>
        </div>
      </section>

      <section id="about" className="py-32 px-6">
        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2
                style={{
                  fontSize: "2.5rem",
                  fontWeight: 700,
                  color: "#8b5a3c",
                  marginBottom: "1.5rem",
                  letterSpacing: "-0.02em",
                }}
              >
                Dibuat dengan Passion
              </h2>
              <p style={{ fontSize: "1.1rem", color: "#666", lineHeight: 1.8, marginBottom: "1rem" }}>
                Di Milkyu, kami percaya bahwa setiap gelas harus menjadi pengalaman. Boba tea kami dibuat fresh setiap hari menggunakan
                bahan-bahan premium yang bersumber dari seluruh dunia.
              </p>
              <p style={{ fontSize: "1.1rem", color: "#666", lineHeight: 1.8 }}>
                Dari bubuk matcha terbaik dari Jepang hingga strawberry segar dan cokelat Belgia, kami tidak pernah
                berkompromi pada kualitas.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="grid grid-cols-2 gap-6"
            >
              <motion.div
                whileHover={{ scale: 1.05 }}
                style={{
                  background: "linear-gradient(135deg, #ffb3c6 0%, #ffe0e8 100%)",
                  padding: "2rem",
                  borderRadius: "1.5rem",
                  boxShadow: "0 10px 30px rgba(255, 179, 198, 0.2)",
                }}
              >
                <div style={{ fontSize: "2.5rem", marginBottom: "0.5rem" }}>🌱</div>
                <div style={{ fontSize: "1.2rem", fontWeight: 600, color: "#8b5a3c", marginBottom: "0.5rem" }}>
                  100% Alami
                </div>
                <div style={{ fontSize: "0.9rem", color: "#666" }}>Tanpa perasa buatan</div>
              </motion.div>

              <motion.div
                whileHover={{ scale: 1.05 }}
                style={{
                  background: "linear-gradient(135deg, #a8d5a8 0%, #d4e8d4 100%)",
                  padding: "2rem",
                  borderRadius: "1.5rem",
                  boxShadow: "0 10px 30px rgba(168, 213, 168, 0.2)",
                }}
              >
                <div style={{ fontSize: "2.5rem", marginBottom: "0.5rem" }}>✨</div>
                <div style={{ fontSize: "1.2rem", fontWeight: 600, color: "#5a9c5a", marginBottom: "0.5rem" }}>
                  Premium
                </div>
                <div style={{ fontSize: "0.9rem", color: "#666" }}>Bahan terbaik</div>
              </motion.div>

              <motion.div
                whileHover={{ scale: 1.05 }}
                style={{
                  background: "linear-gradient(135deg, #c9a584 0%, #e8d4c4 100%)",
                  padding: "2rem",
                  borderRadius: "1.5rem",
                  boxShadow: "0 10px 30px rgba(201, 165, 132, 0.2)",
                }}
              >
                <div style={{ fontSize: "2.5rem", marginBottom: "0.5rem" }}>🤝</div>
                <div style={{ fontSize: "1.2rem", fontWeight: 600, color: "#8b5a3c", marginBottom: "0.5rem" }}>
                  Handcrafted
                </div>
                <div style={{ fontSize: "0.9rem", color: "#666" }}>Dibuat dengan hati</div>
              </motion.div>

              <motion.div
                whileHover={{ scale: 1.05 }}
                style={{
                  background: "linear-gradient(135deg, #ffb3c6 0%, #c9a584 100%)",
                  padding: "2rem",
                  borderRadius: "1.5rem",
                  boxShadow: "0 10px 30px rgba(255, 179, 198, 0.2)",
                }}
              >
                <div style={{ fontSize: "2.5rem", marginBottom: "0.5rem" }}>💝</div>
                <div style={{ fontSize: "1.2rem", fontWeight: 600, color: "#8b5a3c", marginBottom: "0.5rem" }}>
                  Dengan Cinta
                </div>
                <div style={{ fontSize: "0.9rem", color: "#666" }}>Setiap gelasnya</div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      <motion.section
        id="contact"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ duration: 1 }}
        viewport={{ once: true }}
        className="py-32 px-6"
        style={{ background: "linear-gradient(135deg, #ffb3c6 0%, #a8d5a8 50%, #c9a584 100%)" }}
      >
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <MilkyuLogo size={100} className="mx-auto mb-6 text-white" />
            <h2 style={{ fontSize: "2.5rem", fontWeight: 700, color: "white", marginBottom: "1rem" }}>
              Hubungi Kami Hari Ini
            </h2>
            <p style={{ fontSize: "1.2rem", color: "rgba(255, 255, 255, 0.9)", marginBottom: "2rem" }}>
              Rasakan boba tea terbaik di kota
            </p>
            <motion.a
              href="https://wa.me/6282246972263"
              target="_blank"
              rel="noopener noreferrer"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: "0.75rem",
                background: "white",
                color: "#25D366",
                padding: "1rem 2.5rem",
                borderRadius: "9999px",
                fontSize: "1.1rem",
                fontWeight: 600,
                textDecoration: "none",
                boxShadow: "0 10px 30px rgba(0, 0, 0, 0.2)",
              }}
            >
              <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
              </svg>
              WhatsApp
            </motion.a>
          </motion.div>
        </div>
      </motion.section>

      <footer className="py-12 px-6 text-center" style={{ background: "rgba(139, 90, 60, 0.05)" }}>
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-center gap-3 mb-4">
            <MilkyuLogo size={32} className="text-black" />
            <span style={{ fontSize: "1.2rem", fontWeight: 600, color: "#000" }}>Milkyu</span>
          </div>
          <p style={{ fontSize: "0.9rem", color: "#999" }}>© 2026 Milkyu. Hak cipta dilindungi.</p>
        </div>
      </footer>
    </div>
  );
}