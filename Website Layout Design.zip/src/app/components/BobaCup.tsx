import { motion, useMotionValue, useSpring, useTransform } from "motion/react";
import { useState, useRef, useEffect } from "react";
import { MilkyuLogo } from "./MilkyuLogo";

interface BobaCupProps {
  flavor: "matcha" | "strawberry" | "chocolate";
  title: string;
  description: string;
}

export function BobaCup({ flavor, title, description }: BobaCupProps) {
  const [isPressed, setIsPressed] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const pressTimerRef = useRef<NodeJS.Timeout | null>(null);

  const rotateX = useMotionValue(0);
  const rotateY = useMotionValue(0);
  const scale = useMotionValue(1);

  const springRotateX = useSpring(rotateX, { stiffness: 300, damping: 30 });
  const springRotateY = useSpring(rotateY, { stiffness: 300, damping: 30 });
  const springScale = useSpring(scale, { stiffness: 200, damping: 25 });

  const flavorColors = {
    matcha: {
      primary: "#a8d5a8",
      secondary: "#7cb67c",
      accent: "#5a9c5a",
      particle: "#d4e8d4",
    },
    strawberry: {
      primary: "#ffb3c6",
      secondary: "#ff85a8",
      accent: "#ff5689",
      particle: "#ffe0e8",
    },
    chocolate: {
      primary: "#c9a584",
      secondary: "#a67c52",
      accent: "#8b5a3c",
      particle: "#e8d4c4",
    },
  };

  const colors = flavorColors[flavor];

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isPressed) {
      const rect = e.currentTarget.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;

      const rotateYValue = ((x - centerX) / centerX) * 15;
      const rotateXValue = ((centerY - y) / centerY) * 15;

      rotateX.set(rotateXValue);
      rotateY.set(rotateYValue);
    }
  };

  const handleMouseLeave = () => {
    if (!isPressed) {
      rotateX.set(0);
      rotateY.set(0);
    }
  };

  const handlePressStart = () => {
    pressTimerRef.current = setTimeout(() => {
      setIsPressed(true);
      scale.set(1.8);
      rotateX.set(0);
      rotateY.set(0);
    }, 500);
  };

  const handlePressEnd = () => {
    if (pressTimerRef.current) {
      clearTimeout(pressTimerRef.current);
    }
    setIsPressed(false);
    scale.set(1);
  };

  useEffect(() => {
    return () => {
      if (pressTimerRef.current) {
        clearTimeout(pressTimerRef.current);
      }
    };
  }, []);

  return (
    <div className="flex flex-col items-center gap-8">
      <motion.div
        className="relative cursor-pointer select-none"
        style={{
          perspective: "1000px",
          width: "280px",
          height: "380px",
        }}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        onMouseEnter={() => setIsHovered(true)}
        onMouseDown={handlePressStart}
        onMouseUp={handlePressEnd}
        onTouchStart={handlePressStart}
        onTouchEnd={handlePressEnd}
        whileHover={{ scale: 1.05 }}
      >
        <motion.div
          style={{
            rotateX: springRotateX,
            rotateY: springRotateY,
            scale: springScale,
            transformStyle: "preserve-3d",
          }}
          className="relative w-full h-full"
        >
          <svg
            width="280"
            height="380"
            viewBox="0 0 280 380"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            style={{ transform: "translateZ(50px)" }}
          >
            <defs>
              <linearGradient id={`cupGradient-${flavor}`} x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="rgba(255,255,255,0.4)" />
                <stop offset="100%" stopColor="rgba(255,255,255,0.1)" />
              </linearGradient>
              <filter id={`shadow-${flavor}`}>
                <feGaussianBlur in="SourceAlpha" stdDeviation="8" />
                <feOffset dx="0" dy="10" result="offsetblur" />
                <feComponentTransfer>
                  <feFuncA type="linear" slope="0.3" />
                </feComponentTransfer>
                <feMerge>
                  <feMergeNode />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>

            <g filter={`url(#shadow-${flavor})`}>
              <path
                d="M 60 80 L 50 320 Q 50 340 70 340 L 210 340 Q 230 340 230 320 L 220 80 Z"
                fill={colors.primary}
                opacity="0.95"
              />

              <ellipse cx="140" cy="80" rx="80" ry="12" fill={colors.secondary} opacity="0.8" />

              <path
                d="M 60 80 L 50 320 Q 50 340 70 340 L 210 340 Q 230 340 230 320 L 220 80 Z"
                fill={`url(#cupGradient-${flavor})`}
              />

              <ellipse cx="140" cy="40" rx="65" ry="40" fill="rgba(255,255,255,0.2)" />
              <ellipse cx="140" cy="40" rx="60" ry="35" fill="rgba(255,255,255,0.15)" />

              <path
                d="M 75 40 Q 75 30 85 25 L 195 25 Q 205 30 205 40 Q 205 55 195 60 L 85 60 Q 75 55 75 40 Z"
                fill="rgba(255,255,255,0.3)"
              />

              <g opacity={isHovered || isPressed ? "1" : "0.8"} style={{ transform: "translateZ(20px)" }}>
                <foreignObject x="95" y="140" width="90" height="90">
                  <div className="flex items-center justify-center w-full h-full">
                    <MilkyuLogo size={80} className="drop-shadow-lg" style={{ color: colors.accent }} />
                  </div>
                </foreignObject>
              </g>

              {flavor === "matcha" && (
                <>
                  <circle cx="110" cy="100" r="4" fill={colors.particle} opacity="0.6" />
                  <circle cx="170" cy="110" r="3" fill={colors.particle} opacity="0.5" />
                  <circle cx="130" cy="130" r="5" fill={colors.accent} opacity="0.4" />
                </>
              )}

              {flavor === "strawberry" && (
                <>
                  <ellipse cx="100" cy="110" rx="8" ry="6" fill={colors.accent} opacity="0.6" />
                  <ellipse cx="180" cy="120" rx="6" ry="8" fill={colors.accent} opacity="0.5" />
                  <ellipse cx="140" cy="100" rx="7" ry="5" fill={colors.accent} opacity="0.7" />
                </>
              )}

              {flavor === "chocolate" && (
                <>
                  <rect x="105" y="105" width="8" height="3" rx="1" fill={colors.accent} opacity="0.7" />
                  <rect x="165" y="115" width="10" height="3" rx="1" fill={colors.accent} opacity="0.6" />
                  <rect x="130" y="125" width="6" height="3" rx="1" fill={colors.accent} opacity="0.5" />
                </>
              )}

              <g opacity="0.4">
                <circle cx="100" cy="280" r="10" fill={colors.accent} />
                <circle cx="130" cy="290" r="12" fill={colors.accent} />
                <circle cx="160" cy="285" r="11" fill={colors.accent} />
                <circle cx="180" cy="295" r="10" fill={colors.accent} />
                <circle cx="115" cy="305" r="9" fill={colors.accent} />
                <circle cx="145" cy="310" r="11" fill={colors.accent} />
              </g>

              <rect x="100" y="350" width="80" height="15" rx="7" fill="rgba(139, 90, 60, 0.6)" />
            </g>
          </svg>
        </motion.div>

        {isPressed && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute inset-0 pointer-events-none"
          >
            <div className="absolute inset-0 bg-white/10 backdrop-blur-sm rounded-3xl" />
          </motion.div>
        )}
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center max-w-xs"
      >
        <h3 className="mb-2" style={{ color: colors.accent, fontSize: "1.5rem", fontWeight: 600 }}>
          {title}
        </h3>
        <p style={{ color: "#666", fontSize: "0.95rem" }}>{description}</p>
      </motion.div>
    </div>
  );
}
