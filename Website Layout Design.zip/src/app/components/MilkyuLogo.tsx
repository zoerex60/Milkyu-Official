import { motion } from "motion/react";

interface MilkyuLogoProps {
  size?: number;
  className?: string;
  animate?: boolean;
}

export function MilkyuLogo({ size = 48, className = "", animate = false }: MilkyuLogoProps) {
  const logoVariants = {
    initial: { scale: 1, rotate: 0 },
    animate: {
      scale: [1, 1.1, 1],
      rotate: [0, 5, -5, 0],
      transition: {
        duration: 3,
        repeat: Infinity,
        ease: "easeInOut",
      },
    },
  };

  return (
    <motion.div
      variants={logoVariants}
      initial="initial"
      animate={animate ? "animate" : "initial"}
      className={className}
      style={{ width: size, height: size }}
    >
      <svg
        viewBox="0 0 500 500"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        width="100%"
        height="100%"
      >
        <circle cx="250" cy="250" r="240" stroke="currentColor" strokeWidth="12" fill="none" />

        <circle
          cx="250"
          cy="250"
          r="220"
          stroke="currentColor"
          strokeWidth="2"
          strokeDasharray="8 12"
          fill="none"
        />

        <rect x="160" y="130" width="180" height="25" rx="5" fill="currentColor" />
        <rect x="175" y="120" width="150" height="15" rx="7" fill="currentColor" />

        <ellipse cx="250" cy="140" rx="75" ry="40" fill="none" stroke="currentColor" strokeWidth="8" />

        <line x1="250" y1="100" x2="250" y2="145" stroke="currentColor" strokeWidth="6" />

        <path
          d="M 190 155 L 180 350 Q 180 370 200 370 L 300 370 Q 320 370 310 350 L 300 155 Z"
          fill="currentColor"
          opacity="0.9"
        />

        <ellipse cx="250" cy="155" rx="60" ry="10" fill="currentColor" />

        <g transform="translate(250, 240)">
          <text
            x="0"
            y="0"
            textAnchor="middle"
            fontSize="50"
            fontWeight="bold"
            fill="white"
            fontFamily="Arial, sans-serif"
          >
            Milk
          </text>
          <text
            x="0"
            y="45"
            textAnchor="middle"
            fontSize="50"
            fontWeight="bold"
            fill="white"
            fontFamily="Arial, sans-serif"
          >
            yu
          </text>
        </g>

        <ellipse cx="210" cy="340" rx="8" ry="8" fill="white" opacity="0.6" />
        <ellipse cx="235" cy="350" rx="10" ry="10" fill="white" opacity="0.6" />
        <ellipse cx="265" cy="350" rx="10" ry="10" fill="white" opacity="0.6" />
        <ellipse cx="290" cy="340" rx="8" ry="8" fill="white" opacity="0.6" />

        <rect x="215" y="385" width="70" height="12" rx="6" fill="currentColor" opacity="0.7" />
      </svg>
    </motion.div>
  );
}
